from time import sleep
from os import system
sleep(7)
system("python main.py")